package com.test.java8newfeature.lambdaexpression;


/*
 Lamda expression is applicable only for interface
 * */

//@FunctionalInterface
abstract class A5{
	abstract public int squareIt(int num1); 
}

public class WithLamdaExpressionCase2 {
	
	public static void main(String[] args) {
		
	//	A4 a = numx -> numx*numx;  // uncomment and see the reasion
		
		//System.out.println(a.squareIt(5));
	}

}
