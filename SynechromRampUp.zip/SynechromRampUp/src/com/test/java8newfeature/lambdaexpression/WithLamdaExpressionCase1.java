package com.test.java8newfeature.lambdaexpression;


/*
 Lamda expression always apply on that kind of interface only
 which is having only and only single method interface
 * */

//@FunctionalInterface
interface A4{
	public int squareIt(int num1); 
	public int pluseOne(int num1); 
}

public class WithLamdaExpressionCase1 {
	
	public static void main(String[] args) {
		
		//A4 a = numx -> numx*numx;  // uncomment and see the reasion
		
		
		//System.out.println(a.squareIt(5));
	}

}
