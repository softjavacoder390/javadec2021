package com.test.java8newfeature.functionalintr;

@FunctionalInterface
interface FunIntr13 {

	public void m1();

}

//@FunctionalInterface
public class FunctionIntrWithResoToInheri implements FunIntr13 {

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}

}
