package com.test.oops;

class Parent {

	
}

public class Child extends Parent {
	
	public Child() {
		System.out.println("Child.Child()");
	}

	public static void main(String[] args) {

		Child c = new Child();

	}

}