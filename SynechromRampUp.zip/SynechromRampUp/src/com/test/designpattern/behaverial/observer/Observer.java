package com.test.designpattern.behaverial.observer;

public interface Observer {

	void update();

	void subscribeChannel(Channel ch);

}