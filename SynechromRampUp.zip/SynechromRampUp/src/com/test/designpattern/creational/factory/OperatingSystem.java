package com.test.designpattern.creational.factory;

public interface OperatingSystem {
	
	public void specification();

}
