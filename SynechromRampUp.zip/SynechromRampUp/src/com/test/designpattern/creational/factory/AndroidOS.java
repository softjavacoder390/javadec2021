package com.test.designpattern.creational.factory;

public class AndroidOS implements OperatingSystem{
	
	@Override
	public void specification(){
		
	System.out.println("Most Running Android OS...");
	}

}
