package com.test.designpattern.creational.factory;

public class MacOS implements OperatingSystem{
	
	@Override
	public void specification(){
		
	System.out.println("Highly Secure Mac OS...");
	}

}
