package com.test.designpattern.creational.factory;

public class MainFactory {
	
	
	public static void main(String[] args) {
		
	 ObjectGenerationFactor.getOperationSystem("android").specification();
	 
	}

}
