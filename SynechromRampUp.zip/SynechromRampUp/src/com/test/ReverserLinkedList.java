package com.test;

import java.util.Collections;
import java.util.List;

public class ReverserLinkedList {

	public static void testLinkedList() {
		//LinkedList<Integer> linkedList = new LinkedList<>(Arrays.asList(1, 3, 4, 6, 2, 5, 7));
//		int k = 2;
//		System.out.println("i/p : " + linkedList);
//		int startIndex = 0, endIndex = k;
//		while (endIndex <= linkedList.size()) {
//			List<Integer> list = linkedList.subList(startIndex, endIndex);
//			Collections.reverse(list);
//			int subListIndex = startIndex;
//			while (subListIndex < endIndex) {
//				linkedList.set(subListIndex, list.get(subListIndex % k));
//				subListIndex++;
//			}
//			startIndex = endIndex;
//			endIndex = endIndex + k;
//			System.out.println("o/p : " + linkedList);
//			// System.out.println(list);
		//}

	}

}